package td4;

public class Magazine extends Livre{


    public Magazine(String titre, int id, String domaine, int nbPage) {

        super(titre, id, domaine, nbPage);
    }


    @Override
    public String toString() {
        return "Magazine "+super.toString();
    }

    public double calculerPrix(int bonus) {
        double prix = (0.35 * super.nbPage) * (1 + TVA)+bonus;
        return prix;
    }
}
