package td4;

public class Livre {
    protected String titre;
    protected int id;
    protected final double TVA = 0.10;
    protected String domaine;
    protected int nbPage;

    public Livre(String titre, int id, String domaine, int nbPage) {
        this.titre = titre;
        this.id = id;
        this.domaine = domaine;
        this.nbPage = nbPage;
    }

    public String getTitre() {
        return titre;
    }

    public int getId() {
        return id;
    }

    public double getTVA() {
        return TVA;
    }

    public String getDomaine() {
        return domaine;
    }

    public int getNbPage() {
        return nbPage;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDomaine(String domaine) {
        this.domaine = domaine;
    }

    public void setNbPage(int nbPage) {
        this.nbPage = nbPage;
    }

    @Override
    public String toString() {
        return "Livre{" +
                "titre='" + titre + '\'' +
                ", id=" + id +
                ", TVA=" + TVA +
                ", domaine='" + domaine + '\'' +
                ", nbPage=" + nbPage +
                '}';
    }

    public double calculerPrix() {
        double prix = (0.075 * this.nbPage) * (1 + TVA);
        return prix;
    }
}
