package td4;

public class Main {
    public static void main(String[] args) {
        Librairie librairie = new Librairie(4);

        Livre livre1 = new Livre("Livre 1", 1, "AtomicHabits", 200);
        Roman roman1 = new Roman("Roman 1", 2, "Romance", 300);
        Magazine magazine1 = new Magazine("Magazine 1", 3, "Kotlin will kill JAVA", 50);

        librairie.ajoutLiv(livre1);
        librairie.ajoutLiv(roman1);
        librairie.ajoutLiv(magazine1);

        System.out.println("les livres existants :");
        librairie.inventaire();

        Roman nouveauRoman = new Roman("Nouveau Roman", 4, "Romance", 250);
        librairie.ajoutLiv(nouveauRoman);

        System.out.println("tous les livres de la catégorie 'Romance':");
        librairie.inventaire("Romance");

        double montantTotal = 0;
        for (int i = 0; i < librairie.getNb(); i++) {
            Livre livre = librairie.getLivreByIndex(i);
            if (livre instanceof Roman) {
                montantTotal += livre.calculerPrix();
            }
        }
        System.out.println("\nMontant  pour tous les romans disponibles : " + montantTotal);

        Magazine nouveauMagazine = new Magazine("Nouveau Magazine", 5, "Loisirs", 60);
        librairie.ajoutLiv(nouveauMagazine);

        // Le libraire ne peut pas ajouter le nouveau magazine car la capacité de la librairie est plain.
        // Pour remédier à cela, il peut augmenter la capacité de la librairie ou gérer dynamiquement la capacité de la librairie
    }
}
