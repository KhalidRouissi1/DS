package td4;

import javax.swing.plaf.PanelUI;
import java.util.Scanner;

public class Librairie {
    private Livre[] liste;
    private int capacite;
    private int nb;

    public Librairie(int capacite) {
        this.capacite = capacite;
        this.liste = new Livre[capacite];
        this.nb = 0;
    }

    public int getNb() {
        return nb;
    }

    public void inventaire() {
        Scanner inp = new Scanner(System.in);

        for (int i = 0; i < nb; i++) {
            Livre livre = liste[i];
            double prix = livre.calculerPrix();
            if (liste[i] instanceof Magazine) {
                System.out.println("Donnez-moi le bonus :");
                    int bonus = inp.nextInt();
                    prix = livre.calculerPrix(bonus);
                    inp.close();
            }
            System.out.println(livre.getTitre() + " - Prix : " + prix);
        }

    }

    public void inventaire(String categ) {
        for (int i = 0; i < nb; i++) {
            Livre livre = liste[i];
            if (livre.getDomaine().equals(categ)) {
                double prix = livre.calculerPrix();
                System.out.println(livre.getTitre() + " - Prix : " + prix);
            }
        }
    }

    public void ajoutLiv(Livre liv) {
        if (nb < capacite) {
            liste[nb] = liv;
            nb++;
            System.out.println("Livre ajouté avec succès.");
        } else {
            System.out.println("impossible d'ajouter un nouveau livre.");
        }
    }

    public void suppLiv(int num) {
        for (int i = 0; i < nb; i++) {
            if (liste[i].getId() == num) {
                for (int j = i; j < nb - 1; j++) {
                    liste[j] = liste[j + 1];
                }
                liste[nb - 1] = null;
                nb--;
                System.out.println("Livre supprime avec succès.");
                return;
            }
        }
        System.out.println("Aucun livre trouvé avec ce id.");
    }
    public Livre getLivreByIndex(int index)
    {
        return liste[index];
    }
}
