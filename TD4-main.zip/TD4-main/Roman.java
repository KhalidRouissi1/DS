package td4;

public class Roman  extends Livre{
    public Roman(String titre, int id, String domaine, int nbPage) {
        super(titre, id, domaine, nbPage);
    }

    @Override
    public String toString() {
        return "Roman "+super.toString();
    }

    @Override
    public double calculerPrix() {
        double prix = (0.05 * super.nbPage) * (1 + TVA);
        return prix;
    }
}
