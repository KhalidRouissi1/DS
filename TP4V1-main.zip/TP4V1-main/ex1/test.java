package TP4V2_EX1;

public class test {

    public static void main(String args[])
    {
        PointCol pointVert  = new PointCol(1,2,'O',"Green");
        pointVert.afficher();
        pointVert.setColor("Green");


        PointCol pointRed = new PointCol();
        pointRed.setColor("Red");
        pointRed.setX(10);
        pointRed.afficher();
    }
}
