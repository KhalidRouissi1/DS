package iset.dsi2.animalerie;

public class TestHeritage {
    public static void main(String args[]){
        Animal[] T = new Animal[3];
        Animal t1=new Animal("Gray",5);
        T[0]=t1;
        Chats t2 = new Chats("Pink",20,true);
        T[1]=t2;
        Chien t3 = new Chien("Black",30,"BULLDOG");
        T[2] = t3;

        for (Animal animal : T) {
            animal.decrisToi();
            animal.manger();
            animal.boire();
            animal.crier();
            if (animal instanceof Animal) {
                System.out.println("L'espèce de cet animal est inconnue");
            }
        }
    }
}
