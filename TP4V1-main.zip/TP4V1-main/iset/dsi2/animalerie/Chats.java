package iset.dsi2.animalerie;

public class Chats extends Animal{
    private boolean sauvage;

    public Chats() {
    }

    public Chats(String couleur, int poids, boolean sauvage) {
        super(couleur, poids);
        this.sauvage = sauvage;
    }
}
