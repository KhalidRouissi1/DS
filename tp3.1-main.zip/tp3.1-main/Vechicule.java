package tpVech;

public class Vechicule {
    private int num;
    private String marque;
    private String modele;
    private int anneOfCreate;
    private double prix;

    static int count=0;

    public Vechicule(String marque, String modele, int anneOfCreate, double prix) {
        this.marque = marque;
        this.modele = modele;
        this.anneOfCreate = anneOfCreate;
        this.prix = prix;
        count++;
    }


    @Override
    public String toString() {
        return "Vechicule{" +
                "num=" + num +
                ", marque='" + marque + '\'' +
                ", modele='" + modele + '\'' +
                ", anneOfCreate=" + anneOfCreate +
                ", prix=" + prix +
                '}';
    }

    public String getMarque() {
        return marque;
    }

    public String getModele() {
        return modele;
    }

    public double getPrix() {
        return prix;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

    public void setModele(String modele) {
        this.modele = modele;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public int getAnneOfCreate() {
        return anneOfCreate;
    }

    public static int getCount() {
        return count;
    }

    public void decrisVehicule()
    {
        System.out.println(this);
    }
}


