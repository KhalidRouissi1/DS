package tpVech;

import java.util.Arrays;

public class AgenceMobiliere {
    private int max;
    private Vechicule[] tab;

    private int nb= 0;

    public Vechicule getElment(int i) {
        return tab[i];
    }

    public AgenceMobiliere(int max) {
        this.max = max;
        tab = new Vechicule[this.max];

    }
    public void ajoutVechicule(Vechicule v)
    {
        if(this.nb<this.max && this.nb >=0) {
            this.tab[nb] = v;
            this.nb++;
        }
    }

    public void selection(int n)
    {

        if(n>0 && n<nb)
            this.tab[n].decrisVehicule();
        else {
            System.out.println("Cette case est vide");

        }
    }




    public  void selection(String marque)
    {
        boolean test = false;

        for(int i=0;i<nb;i++)
        {
            if(tab[i].getMarque()==marque)
            {
                test = true;
                tab[i].decrisVehicule();
            }

        }
        if(!test)
            System.out.println("There is no car with this marque");    }


    public  void selection(double px)
    {
        boolean test = false;
        for(int i=0;i<nb;i++)
        {
            if(tab[i].getPrix()<px)
            {
                test = true;
                tab[i].decrisVehicule();
            }

        }
        if(!test)
            System.out.println("There is no car with this price");
    }


    public Vechicule getOlderCar() {
        Vechicule olderCar = tab[0];

        for(int i =1;i<this.nb;i++)
        {
            if(tab[i].getAnneOfCreate()<olderCar.getAnneOfCreate())
            {
                olderCar = tab[i];
            }

        }
        return  olderCar;
    }

    public void getAllDetailes()
    {

        for(int i =0;i<this.nb;i++)
        {
            selection(i);
        }
    }
}
