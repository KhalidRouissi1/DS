package tpVech;

import tpVech.AgenceMobiliere;
import tpVech.Vechicule;

public class Main {
    public static void main(String[] args) {
    AgenceMobiliere v = new AgenceMobiliere(10);
    Vechicule v1 = new Vechicule("Clio","Classique",2000,20.000);
    v.ajoutVechicule(v1);
    Vechicule w = new Vechicule("Mercedes","Fantome",2008,60.000);
    v.ajoutVechicule(w);
    Vechicule x = new Vechicule("KIA","Picanti",2012 ,35.000);
    v.ajoutVechicule(x);
    System.out.println("Car Detailes");
    v.getAllDetailes();
    System.out.println("Car Detailes");
            v.selection("Mercedes");

    System.out.println("Car price lower than");
            v.selection(40.000);


        System.out.println("Older cars in the parking");

        v.getOlderCar().decrisVehicule();

    }


}

