public class Courrier {
    protected boolean modExp= true;
    private String addresseDeDest;
    final double tarif = 0.5;

    public Courrier(boolean modExp, String addresseDeDest) {
        this.modExp = modExp;
        this.addresseDeDest = addresseDeDest;
    }


    public boolean estValide()
    {
        return this.addresseDeDest != null && !this.addresseDeDest.isEmpty();
    }


    public  void decrire()
    {
        System.out.println( "Courrier{" +
                "modExp=" + modExp +
                ", addresseDeDest='" + addresseDeDest + '\'' +
                ", tarif=" + tarif +
                '}');
    }


    public double affranchir()
    {
       if(estValide())
       {

           return modExp ? this.tarif*2 : this.tarif;
       }
       else
           return 0;
    }





}
