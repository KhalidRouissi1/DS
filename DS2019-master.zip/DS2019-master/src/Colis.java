public class Colis extends Courrier {




    private double poids;
    private double volume;


    public Colis(boolean modExp, String addresseDeDest, double poids, double volume) {
        super(modExp, addresseDeDest);
        this.poids = poids;
        this.volume = volume;
    }


    @Override
    public void decrire()
    {
        super.decrire();
        System.out.println(" Poids"+this.poids+" Volume "+this.volume);
    }

    @Override
    public  double affranchir()
    {
        if(super.estValide())
        {
            if(super.modExp)
            {
                return (0.25 * volume)+ (poids/1000)* 1.0;

            }
            else {
                return ((0.25 * volume)+ (poids/1000)* 1.0)*2;
            }
        }
        else
            return 0;
    }
}
