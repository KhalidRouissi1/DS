public class Main {
    public static void main(String[] args) {
        BoiteCourrier mailbox = new BoiteCourrier(3);

        // Create some Courrier objects and add them to the mailbox
        Courrier courrier1 = new Courrier(true, "Sender 1");
        Letter courrier2 = new Letter(true, "Sender 2", 7, "a4");
        Colis courrier3 = new Colis(false, "Sender 3", 4.0, 4.3);
        mailbox.tabCour[0] = courrier1;
        mailbox.tabCour[1] = courrier2;
        mailbox.tabCour[2] = courrier3;

        mailbox.affranchir();
        int invalidCount = mailbox.courriersInvalides();
        System.out.println("Number of invalid courriers: " + invalidCount);

        // Display all courriers in the mailbox
        mailbox.afficher();
    }
}
