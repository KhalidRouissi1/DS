public class Letter extends Courrier{
    private double poids;
    private String format;
    public Letter(boolean modExp, String addresseDeDest, int poids, String format) {
        super(modExp, addresseDeDest);
        this.poids = poids;
        if(!equals(format.toUpperCase(),"A3")  && !equals(format.toUpperCase(),"A4"))
        {
            System.out.println("Your format is wrong");
            return;
        }
        else {
            this.format = format.toUpperCase();
        }
    }


    @Override
    public void decrire()
    {
        super.decrire();
        System.out.println(" Poids"+this.poids+" Format "+this.format);
    }
    @Override
    public  double affranchir()
    {
       double  tarifBase = this.format =="A4"?2.50 : 3.50;
        if(super.estValide())
        {
            if(super.modExp)
            {
                return (tarifBase +0.5 * (poids/1000))*2;

            }
            else {
                return tarifBase +0.5 * (poids/1000);
            }
        }
        else
            return 0;
    }
}
