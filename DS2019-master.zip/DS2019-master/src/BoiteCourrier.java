public class BoiteCourrier {

    Courrier[] tabCour;

    public BoiteCourrier(int n) {
        this.tabCour = new Courrier[n];
    }
    public double affranchir()
    {
        double total=0;
        for (int i=0;i< tabCour.length;i++)
        {
            total+=tabCour[i].affranchir();
        }
        return total;
    }


    public int courriersInvalides()
    {
        int invalid=0;
        for (int i=0;i<this.tabCour.length;i++)
        {
            invalid+=tabCour[i].estValide()?0:1;
        }
        return invalid;
    }


    public void afficher()
    {
        for (int i=0;i<this.tabCour.length;i++)
        {
            if(tabCour[i].estValide())
                tabCour[i].decrire();
            else
            {
                System.out.println("Cest courrire est Invalid ");
                tabCour[i].decrire();

            }

        }
    }
}

