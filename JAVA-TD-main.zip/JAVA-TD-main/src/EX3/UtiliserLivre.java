package EX3;

public class UtiliserLivre {
    public static void main(String[] args) {
        Livre l1 =new Livre("Coelho","L'alchimiste",225);
        l1.setPrix(0);
        String msg = l1.testPrix()? "Le prix est modifie":"Le prix est fixe";
        System.out.println(msg);
        l1.setPrix(100);
        msg = l1.testPrix()? "Le prix est modifie":"Le prix est fixe";
        System.out.println(msg);
    }
}
