package EX2;

public class UtiliserLivre {
    public static void main(String[] args) {
        Livre[] livres() =new Livre[3];
        livres[0] =new Livre("Coelho","L'alchimiste",225);
        livres[1] =new Livre("Le Coran",508);
        livres[2] =new Livre("Harry Potter","JK Rowling",0);
        // il n'y a aucune construction mentionnée dans le TD qui entre uniquement le titre et l'auteur alors je remplire 0
        for(int i=0;i<3;i++){

                    System.out.println(livres[i]);

        }
   
        l2.setAuteur("Paulo Coelho");
        l3.setNbPages(461);
        }
}
