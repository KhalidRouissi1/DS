package EX2;

class Livre {
    private String titre, auteur;
    private float nbPages;
    public Livre (String auteur,String titre,float nbP) {
        this.auteur =auteur;
        this.titre = titre;
        this.nbPages = nbP;
    }
    public Livre (String titre,float nbP) {
        this.titre = titre;
        this.nbPages = nbP;
    }

    public Livre()
    {
        this.nbPages = 0;
    }

    public String getAuteur() {
            return auteur;
        }

    public String getTitre() {
        return titre;
    }

    public float getNbPages() {
        return nbPages;
    }
    public void setNbPages (float nb) {
        if(nb >20)
            this.nbPages = nb;
        else
            System.out.println("Your number is so low you should enter a number greater than 20");
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public void setAuteur(String auteur) {
        this.auteur = auteur;
    }

    @Override
    public String toString() {
        return "Livre intitulé " +
                titre  +
                " de " + auteur +
                ", contenant " + nbPages +
                " pages.";
    }
    public void decrire()
    {
        System.out.println(this.toString());
    }
}