package EX1;

class Livre {
    private String titre, auteur;
    private float nbPages;
    public Livre (String auteur,String titre) {
        this.auteur =auteur;
        this.titre = titre;

    }
        public String getAuteur() {
            return auteur;
        }

            public void setNbPages (float nb) {
                nbPages = nb;
            }
        }