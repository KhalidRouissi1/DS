package EX1;

public class UtiliserLivre {
    public static void main(String[] args) {
        Livre l1 =new Livre("Khaled Rouissi","Vision");
        Livre l2 =new Livre("Khaled C#","Kotline is better than JAVA");
        String msg = l2.getAuteur() == l1.getAuteur() ? "Same Auther":"Diffrent Auther";
        System.out.println(msg) ;

        }
}
