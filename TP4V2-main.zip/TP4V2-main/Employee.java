package TP4V1;

public class Employee extends Salerie{

    public final String type ="Emp";
    private double Hsupp;
    private double PHsupp;


    public Employee(int matricule, String nom, int recrutement, int hsupp, double PHsupp) {
        super(matricule, nom, recrutement);
        Hsupp = hsupp;
        this.PHsupp = PHsupp;
    }

    public double getHsupp() {
        return Hsupp;
    }

    public double getPHsupp() {
        return PHsupp;
    }

    public void setHsupp(int hsupp) {
        Hsupp = hsupp;
    }

    public void setPHsupp(double PHsupp) {
        this.PHsupp = PHsupp;
    }


    @Override
    public String toString() {
        return super.toString()+"Hsupp=" + Hsupp +
                ", PHsupp=" + PHsupp ;
    }

    @Override
    public void affiche()
    {
        System.out.println(this.getClass().getSimpleName());
        System.out.println(this.toString());

    }


    public double salarie()
    {
        return super.salarie() +(this.Hsupp * this.PHsupp);
    }

}
