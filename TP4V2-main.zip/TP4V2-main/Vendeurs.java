package TP4V1;

public class Vendeurs extends  Salerie{
    public final String type ="Vend";

    private int vente;
    private double pourcentage;

    public Vendeurs(int matricule, String nom, int recrutement, int vente, double pourcentage) {
        super(matricule, nom, recrutement);
        this.vente = vente;
        this.pourcentage = pourcentage;
    }


    public int getVente() {
        return vente;
    }

    public double getPourcentage() {
        return pourcentage;
    }

    public void setVente(int vente) {
        this.vente = vente;
    }

    public void setPourcentage(double pourcentage) {
        this.pourcentage = pourcentage;
    }

    @Override
    public String toString() {
        return super.toString()+"vente=" + vente +
                ", pourcentage=" + pourcentage;
    }

    @Override
    public void affiche()
    {
        System.out.println(this.getClass().getSimpleName());
        System.out.println(this);
    }


    public double salarie()
    {
        return super.salarie() +(this.pourcentage*this.vente);
    }

}
