package TP4V1;

public class Entreprise {
    public static void main(String[] args) {
        Salerie[] tabSalarie = new Salerie[5];
        Employee e1 = new Employee(12345,"Walid",2002,15,4);
        tabSalarie[0] = e1;
        Vendeurs v1 = new Vendeurs(23445,"Yessine",2007,1000,0.1);
        tabSalarie[1] = v1;

        Vendeurs v2 = new Vendeurs(65478,"Nassime",2000,700,0.1);
        tabSalarie[2] = v2;
        Employee e2 = new Employee(87698,"Aymen",2003,19,5);
        tabSalarie[3] = e2;
        Employee e3 = new Employee(12345,"Khaled",2008,7,4);
        tabSalarie[4] = e3;

        System.out.println("******************************** Liste des Employés*****************************\n");
        for(int i=0 ; i<tabSalarie.length;i++)
        {
            if(tabSalarie[i] instanceof Employee)
            {
                tabSalarie[i].affiche();
            }
        }
        System.out.println("*****************************************************************************\n");
        System.out.println("******************************** Liste des Vendeur*****************************\n");
        for(int i =0;i<tabSalarie.length;i++)
        {
            if(tabSalarie[i] instanceof Vendeurs)
            {
                tabSalarie[i].affiche();
            }
        }
        System.out.println("*****************************************************************************");

        System.out.println("******************* Nom du salarié le plus ancien dans l'entreprise ********************\n");
                Salerie.laPlusAncien(tabSalarie);
        System.out.println("*****************************************************************************\n");


        System.out.println("******************* Nom du salarié le plus ancien dans l'entreprise ********************\n");
        Salerie plusAnc = Salerie.laPlusAncien(tabSalarie);
        System.out.println("Nom "+plusAnc.getNom()+" recrute en l'an "+plusAnc.getRecrutement());
        System.out.println("*****************************************************************************\n");
        System.out.println("******************* Nom du salarié le plus ancien dans l'entreprise ********************\n");
        Salerie MAX = null;
        for(int i =1;i<tabSalarie.length;i++)
        {
            if(tabSalarie[i] instanceof Vendeurs)
            {
            if(MAX != null) {
                if (MAX.salarie() < tabSalarie[i].salarie())
                    MAX = tabSalarie[i];
            }
            else
            {
                    MAX = tabSalarie[i];
            }
            }

            }
        System.out.println("Matricule "+MAX.getMatricule()+" de salaire "+MAX.salarie()+" DT");
        System.out.println("*****************************************************************************\n");
    }



}