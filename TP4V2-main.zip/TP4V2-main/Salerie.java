package TP4V1;

public class Salerie {
    final public String type = "Sal";
    private   int Matricule=0;
    private String Nom;
    private int Recrutement;

    public Salerie(int matricule, String nom, int recrutement) {
        Matricule = matricule;
        Nom = nom;
        Recrutement = recrutement;
    }

    public int getMatricule() {
        return Matricule;
    }

    public String getNom() {
        return Nom;
    }

    public double getRecrutement() {
        return Recrutement;
    }

    public void setMatricule(int matricule) {
        Matricule = matricule;
    }

    public void setNom(String nom) {
        Nom = nom;
    }

    public void setRecrutement(int recrutement) {
        Recrutement = recrutement;
    }


    @Override
    public String toString() {
        return
                "Matricule=" + Matricule +
                ", Nom='" + Nom + '\'' +
                ", Recrutement=" + Recrutement;
    }
    public void affiche()
    {
        System.out.println(toString());
    }
    public double salarie()
    {
        return this.Recrutement < 2005 ? 400 : 280;
    }

    static Salerie laPlusAncien(Salerie[] s)
    {
        Salerie min = s[0];
        for(int i =1;i<s.length;i++)
        {
            if(min.getRecrutement()  > s[i].getRecrutement())
                min = s[i];
        }
        return  min;
    }

}
