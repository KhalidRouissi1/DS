package Dict;

public class MainDict {
    public static void main(String[] args) {
        Dictionnaire larousse = new Dictionnaire(10, "Larousse");

        MotDico mot1 = new MotDico("chat", "Un animal domestique.");
        MotDico mot2 = new MotDico("chien", "Un autre animal domestique.");
        MotDico mot3 = new MotDico("oiseau", "Un animal à plumes.");

        larousse.ajouterMot(mot1);
        larousse.ajouterMot(mot2);
        larousse.ajouterMot(mot3);

        larousse.listerDico();



        int index = larousse.chercherMot("chien");
        if (index != -1) {
            MotDico motChien = larousse.getDicoByIndex(index);
            System.out.println("Le mot 'chien' existe dans le dictionnaire : " + motChien.getDefinition());
        } else {
            System.out.println("Le mot 'chien' n'existe pas dans le dictionnaire.");
        }
         index = larousse.chercherMot("C#");
        if (index != -1) {
            MotDico motChien = larousse.getDicoByIndex(index);
            System.out.println("Le mot 'C#' existe dans le dictionnaire : " + motChien.getDefinition());
        } else {
            System.out.println("Le mot 'C#' n'existe pas dans le dictionnaire.");
        }

        int nbSynonymesChien = larousse.nbSynonymes(mot2);
        System.out.println("Le nombre de synonymes pour 'chien' est : " + nbSynonymesChien);

        larousse.supprimerMot("oiseau");
        larousse.listerDico();
    }

}
