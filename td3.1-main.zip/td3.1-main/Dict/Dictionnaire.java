package Dict;

public class Dictionnaire {
    static int nbMots;
    private MotDico[] dico;
    private String nom;

    public Dictionnaire(int capacite, String nom) {
        this.dico = new MotDico[capacite];
        this.nom = nom;
    }
    public void ajouterMot(MotDico m )
    {
        if (nbMots < dico.length) {
            dico[nbMots] = m;
            nbMots++;
        } else {
            System.out.println("Dictionnaire is Full.");
        }
    }


    public void supprimerMot(String mot) {
        int index = chercherMot(mot);
        if (index != -1) {
            for (int i = index; i < nbMots - 1; i++) {
                dico[i] = dico[i + 1];
            }
            nbMots--;
        } else {
            System.out.println("Le mot n'existe pas dans le dictionnaire.");
        }
    }

    public int chercherMot(String mot) {
        for (int i = 0; i < nbMots; i++) {
            if (dico[i].getMot().equals(mot)) {
                return i;
            }
        }
        return -1;
    }
    public void listerDico() {
        for(int i=0;i<nbMots;i++)
        {
            System.out.println(dico[i]);
        }

    }
    public MotDico getDicoByIndex(int index)
    {
        return dico[index];
    }
    public int nbSynonymes(MotDico m) {
        int nbSyn = 0;
        for (int i = 0; i < nbMots; i++) {
            if (m.synonyme(dico[i])) {
                nbSyn++;
            }
        }
        return nbSyn;
    }


}
