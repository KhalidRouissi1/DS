package Dict;

import java.util.Random;

public class MotDico
{
    public static int num ;
    private String mot;
    private String definition;

    public MotDico(String mot,String definition) {
        this.mot = mot;
        this.definition = definition;
        num++;
    }

    public String getMot() {
        return mot;
    }

    public String getDefinition() {
        return definition;
    }

    public void setMot(String s) {
        this.mot = s;
    }

    public void setDefinition(String s) {
        this.definition = s;
    }

    public boolean synonyme(MotDico mot) {
        return mot.getDefinition() == this.definition;
    }

    @Override
    public String toString() {
        return "MotDico{" +
                "mot='" + mot + '\'' +
                ", definition='" + definition + '\'' +
                '}';
    }
}
