package Moyeens;

public class Tab {
    final static int NMAX = 40;

    static float somme_element(float t[]) {
        float sum = 0;
        for (int i = 0; i < t.length; i++) {
            sum += t[i];
        }
        return sum;
    }

    static float[] additioner(float[] t1, float[] t2) {
        float[] result = new float[t1.length];
        for (int i = 0; i < t1.length; i++) {
            result[i] = t1[i] + t2[i];
        }
        return result;
    }

    static float[] produit(float t1[], float t2[]) {
        float[] result = new float[t1.length];
        for (int i = 0; i < t1.length; i++) {
            result[i] = t1[i] * t2[i];
        }
        return result;
    }

    static void lister(float[] t) {
        for (int i = 0; i < t.length; i++) {
            System.out.println(t[i]);
        }
    }

    static float[] moy(float[] tCtrl,float[] tExam) {
        float[] moy = new float[tCtrl.length];
        for (int i = 0; i < tCtrl.length; i++) {
            moy[i] =( tCtrl[i]+2*tExam[i])/3;
        }
        return  moy;
    }
    static float[] additionner(float x,float[] t) {
        for (int i = 0; i < t.length; i++) {
            t[i]+=x;
        }
        return  t;
    }



}
