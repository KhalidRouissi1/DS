package Moyeens;

import java.util.Scanner;

public class CalculMoyenne {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int nb;
        System.out.println("Enter student number");
        nb = scanner.nextInt();
        if (nb <= 0 || nb > Tab.NMAX) {
            System.out.println("nb must be a positive int less than or equal to " + Tab.NMAX);
            return;
        }
        float[] noteCtrl = new float[nb];
        float[] noteExam = new float[nb];

        System.out.println("Enter " + nb + " values for noteCtrl:");
        for (int i = 0; i < nb; i++) {
            noteCtrl[i] = scanner.nextFloat();
        }

        System.out.println("Enter " + nb + " values for noteExam:");
        for (int i = 0; i < nb; i++) {
            noteExam[i] = scanner.nextFloat();
        }


        float[] moy = new float[nb];
        moy = Tab.moy(noteCtrl,noteExam);
        Tab.lister(moy);
        Tab.additionner(1.5F,noteExam);
        Tab.lister(noteExam);


        // IF table noteExam and noteCtrl has diffrent size the programme will crash cause I can't add with null
        // SO i need to controle the size before I start fill in
    }
}

